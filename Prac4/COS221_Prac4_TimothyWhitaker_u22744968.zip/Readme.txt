Follow these steps to use the program:
1. open your sql server management tool and run the sql dump file in the in the DB Dumps folder
2. Setup the following enviroment variables:
    • dvdrental DB PROTO = jdbc:mariadb://
    • dvdrental DB HOST = localhost
    • dvdrental DB PORT = 3306
    • dvdrental DB NAME = u22744968_sakila
    • dvdrental DB USERNAME = Your username for the database
    • dvdrental DB PASSWORD = Your password for the database
3. Run the program u22744968_sakila.jar